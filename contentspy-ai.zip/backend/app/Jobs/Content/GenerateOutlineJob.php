<?php
namespace App\Jobs\Content;

use App\Models\Article;
use App\Services\Content\ContentPipelineOrchestrator;
use App\Services\Content\Steps\OutlineGeneratorService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class GenerateOutlineJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries   = 2;
    public int $timeout = 120;

    public function __construct(
        private readonly int    $articleId,
        private readonly string $reservationToken,
        private readonly int    $workspaceId,
    ) {}

    public function backoff(): array
    {
        return [30, 60];
    }

    public function handle(OutlineGeneratorService $service, ContentPipelineOrchestrator $orchestrator): void
    {
        $article = Article::findOrFail($this->articleId);

        // Idempotency: skip if already past this step
        if (! in_array($article->generation_status, ['pending'])) {
            return;
        }

        $article->advancePipelineStep('outline');
        $outline = $service->generate($article);

        $article->update(['outline' => $outline]);

        GenerateArticleBodyJob::dispatch($this->articleId, $this->reservationToken, $this->workspaceId)
            ->onQueue('content_generation');
    }

    public function failed(\Throwable $e): void
    {
        $article = Article::find($this->articleId);
        if ($article) {
            app(ContentPipelineOrchestrator::class)->handleFailure($article, $this->reservationToken, $e);
        }
    }
}
